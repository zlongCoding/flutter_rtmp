package holo.mark.flutter_rtmp

import android.hardware.Camera


class CameraHelper{


    fun getFixableSize(width: Int ,height: Int){
         var inf = Camera.CameraInfo()

    }


}
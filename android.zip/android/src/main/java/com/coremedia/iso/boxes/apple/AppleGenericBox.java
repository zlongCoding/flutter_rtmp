package com.coremedia.iso.boxes.apple;

import com.googlecode.mp4parser.AbstractContainerBox;

/**
 *
 */
public final class AppleGenericBox extends AbstractContainerBox {
    public static final String TYPE = "----";

    public AppleGenericBox() {
        super(TYPE);
    }

}